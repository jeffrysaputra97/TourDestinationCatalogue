package com.ithb.jeffry.tourdestinationcatalogue;

public class Location {
    private int position;
    private String name;
    private String shortDesc;
    private String currency;
    private String language;
    private String hotelPriceRange;
    private String flightDurationPrice;
    private String funFact;
    private String detail;
    private String photo;

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    public String getShortDesc() {
        return shortDesc;
    }

    public void setShortDesc(String shortDesc) {
        this.shortDesc = shortDesc;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getHotelPriceRange() {
        return hotelPriceRange;
    }

    public void setHotelPriceRange(String hotelPriceRange) {
        this.hotelPriceRange = hotelPriceRange;
    }

    public String getFlightDurationPrice() {
        return flightDurationPrice;
    }

    public void setFlightDurationPrice(String flightDurationPrice) {
        this.flightDurationPrice = flightDurationPrice;
    }

    public String getFunFact() {
        return funFact;
    }

    public void setFunFact(String funFact) {
        this.funFact = funFact;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }
}
