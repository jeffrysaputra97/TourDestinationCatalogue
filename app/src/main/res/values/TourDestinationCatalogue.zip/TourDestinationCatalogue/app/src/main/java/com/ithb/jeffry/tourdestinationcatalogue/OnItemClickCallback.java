package com.ithb.jeffry.tourdestinationcatalogue;

public interface OnItemClickCallback {
    void onItemClicked(Location data);
}
